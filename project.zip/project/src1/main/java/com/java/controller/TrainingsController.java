package com.java.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.model.Trainings;
import com.java.repo.TrainingsRepository;



@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class TrainingsController {

	@Autowired
	private TrainingsRepository repository;

	@PostMapping(value = "/trainings/create")
	public ResponseEntity<Void> postTrainings(@RequestBody Trainings trainings) {

		repository.save(new Trainings ( trainings.getTid(), trainings.getUser_id(), trainings.getMentor_id(), trainings.getSkill_id(), trainings.getStatus(),  trainings.getProgress(),trainings.getRating(),
				trainings.getStart_time(), trainings.getEnd_time(), trainings.getStart_date(), trainings.getEnd_date(), trainings.getAmount_received(), trainings.getFees(),
				trainings.getUser_name(), trainings.getMentor_name(), trainings.getSkill_name()));
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	} 

	
	@GetMapping("/trainings/get/{tid}")
	public Optional<Trainings> getAllDetails(@PathVariable("tid") long tid) {
		System.out.println("Get all Trainings of id...");
		Optional<Trainings> trainings = repository.findById(tid);
		return trainings;
	}
	
	@GetMapping("/trainings/getCompleted/{user_id}")
	public List<Trainings> getAllCompletedTraining(@PathVariable("user_id") long user_id)
	{
			System.out.println("Get all Completed Trainings of id...");
			List<Trainings> trainings = repository.getAllCompletedTraining(user_id);
			return trainings;
	}
	@GetMapping("/trainings/getCompletedMentor/{mentor_id}")
	public List<Trainings> getAllCompletedTrainingMentor(@PathVariable("mentor_id") long mentor_id)
	{
			System.out.println("Get all Completed Trainings of id...");
			List<Trainings> trainings = repository.getAllCompletedTrainingMentor(mentor_id);
			return trainings;
	}
	
	
	@GetMapping("/trainings/getOnProgress/{user_id}")
	public List<Trainings> getAllOnProgress(@PathVariable("user_id") long user_id)
	{
			System.out.println("Get all On Progress Trainings of id...");
			List<Trainings> trainings = repository.getAllOnProgress(user_id);
			return trainings;
	}
	
	
	@GetMapping("/trainings/getFinalize/{tid}")
	public List<Trainings> getAllFinalize(@PathVariable("tid") long tid)
	{
			System.out.println("Get all Finalize  Trainings of id...");
			List<Trainings> trainings = repository.getAllFinalize(tid);
			return trainings;
	}
	
	@PutMapping("/trainings/getApprove/{tid}")
	public ResponseEntity<Trainings> getAllApprove(@PathVariable("tid") long tid) {
		System.out.println("Update Customer with ID = " + tid + "...");

		Optional<Trainings> trainingsData = repository.findById(tid);

		if (trainingsData.isPresent()) {
			Trainings _customer = trainingsData.get();
			_customer.setStatus("approved");
			return new ResponseEntity<>(repository.save(_customer), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
}
