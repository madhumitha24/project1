package com.javasampleapproach.springrest.mysql.model;

public @interface Mentor {

}
