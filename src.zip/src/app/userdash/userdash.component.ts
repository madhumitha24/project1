import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userdash',
  templateUrl: './userdash.component.html',
  styleUrls: ['./userdash.component.css']
})
export class UserdashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
