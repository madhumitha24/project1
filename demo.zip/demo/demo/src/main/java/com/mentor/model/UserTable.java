package com.mentor.model;

import java.util.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "UserTable")
public class UserTable {
       @Id
       @GeneratedValue(strategy = GenerationType.AUTO)
       private int id;
       @Column(name = "user_name")
       private String username;
       @Column(name = "password")
       private String password;
       @Column(name = "firstName")
       private Date firstName;
       @Column(name = "lastName")
       private int lastName;
       @Column(name = "reg_datetime")
       private String regDateTime;
       @Column(name = "reg_code")
       private int regCode;
       @Column(name = "year_of_experience")
       private int yearOfExperience;

       public UserTable() {
           super();
    }

       public UserTable(int id, String username, String password, Date firstName, int lastName, String regDateTime,
			int regCode, int yearOfExperience) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regDateTime = regDateTime;
		this.regCode = regCode;
		this.yearOfExperience = yearOfExperience;
	}



	

       

       
       public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getFirstName() {
		return firstName;
	}

	public void setFirstName(Date firstName) {
		this.firstName = firstName;
	}

	public int getLastName() {
		return lastName;
	}

	public void setLastName(int lastName) {
		this.lastName = lastName;
	}

	public String getRegDateTime() {
		return regDateTime;
	}

	public void setRegDateTime(String regDateTime) {
		this.regDateTime = regDateTime;
	}

	public int getRegCode() {
		return regCode;
	}

	public void setRegCode(int regCode) {
		this.regCode = regCode;
	}

	public int getYearOfExperience() {
		return yearOfExperience;
	}

	public void setYearOfExperience(int yearOfExperience) {
		this.yearOfExperience = yearOfExperience;
	}

	

       

       @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + id;
		result = prime * result + lastName;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + regCode;
		result = prime * result + ((regDateTime == null) ? 0 : regDateTime.hashCode());
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		result = prime * result + yearOfExperience;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserTable other = (UserTable) obj;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (id != other.id)
			return false;
		if (lastName != other.lastName)
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (regCode != other.regCode)
			return false;
		if (regDateTime == null) {
			if (other.regDateTime != null)
				return false;
		} else if (!regDateTime.equals(other.regDateTime))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		if (yearOfExperience != other.yearOfExperience)
			return false;
		return true;
	}

	

}
