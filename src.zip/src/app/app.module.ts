import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from'@angular/router';
import { AdminsignupComponent } from './adminsignup/adminsignup.component';
import { PaymentComponent } from './payment/payment.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { AdminComponent } from './admin/admin.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';
import { HomeComponent } from './home/home.component';
import { UserproposedComponent } from './userproposed/userproposed.component';
import { UserdashComponent } from './userdash/userdash.component';
import { HomedashComponent } from './homedash/homedash.component';
import { ServiceComponent } from './service/service.component';
import { MentorpaymentComponent } from './mentorpayment/mentorpayment.component';

@NgModule({
  declarations: [
    AppComponent,
    UsersignupComponent,
    MentorsignupComponent,
    LoginComponent,
    AdminsignupComponent,
    PaymentComponent,
    ScheduleComponent,
    UserprofileComponent,
    MentorprofileComponent,
    AdminComponent,
    AdminprofileComponent,
    HomeComponent,
    UserproposedComponent,
    UserdashComponent,
    HomedashComponent,
    ServiceComponent,
    MentorpaymentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
