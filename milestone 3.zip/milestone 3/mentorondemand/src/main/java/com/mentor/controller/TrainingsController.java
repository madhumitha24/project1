package com.mentor.controller;

public class TrainingsController {

}
