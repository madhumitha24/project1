package com.mentor.model;

import java.sql.Time;
import java.util.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TrainingTable")
public class TrainingTable {
       @Id
       @GeneratedValue(strategy = GenerationType.AUTO)
       private int id;
       @Column(name = "user_id")
       private int userID;
       @Column(name = "mentor_id`")
       private int mentorId;
       @Column(name = "skill_id")
       private int skillId;
       @Column(name = "status")
       private String status;
       @Column(name = "progress")
       private String progress;
       @Column(name = "start_time")
       private Time startTime;
       @Column(name = "end_time")
       private Time endTime;
       @Column(name = "start_date")
       private Date startDate;
       @Column(name = "end_date")
       private Date endDate;
       @Column(name = "rating")
       private int Rating;
       @Column(name = "amount_received")
       private int amountReceived;
       
       
       
       
  public TrainingTable()
        {
        	super();
        }




public TrainingTable(int id, int userID, int mentorId, int skillId, String status, String progress, Time startTime,
		Time endTime, Date startDate, Date endDate, int rating, int amountReceived) {
	super();
	this.id = id;
	this.userID = userID;
	this.mentorId = mentorId;
	this.skillId = skillId;
	this.status = status;
	this.progress = progress;
	this.startTime = startTime;
	this.endTime = endTime;
	this.startDate = startDate;
	this.endDate = endDate;
	Rating = rating;
	this.amountReceived = amountReceived;
}




public int getId() {
	return id;
}




public void setId(int id) {
	this.id = id;
}




public int getUserID() {
	return userID;
}




public void setUserID(int userID) {
	this.userID = userID;
}




public int getMentorId() {
	return mentorId;
}




public void setMentorId(int mentorId) {
	this.mentorId = mentorId;
}




public int getSkillId() {
	return skillId;
}




public void setSkillId(int skillId) {
	this.skillId = skillId;
}




public String getStatus() {
	return status;
}




public void setStatus(String status) {
	this.status = status;
}




public String getProgress() {
	return progress;
}




public void setProgress(String progress) {
	this.progress = progress;
}




public Time getStartTime() {
	return startTime;
}




public void setStartTime(Time startTime) {
	this.startTime = startTime;
}




public Time getEndTime() {
	return endTime;
}




public void setEndTime(Time endTime) {
	this.endTime = endTime;
}




public Date getStartDate() {
	return startDate;
}




public void setStartDate(Date startDate) {
	this.startDate = startDate;
}




public Date getEndDate() {
	return endDate;
}




public void setEndDate(Date endDate) {
	this.endDate = endDate;
}




public int getRating() {
	return Rating;
}




public void setRating(int rating) {
	Rating = rating;
}




public int getAmountReceived() {
	return amountReceived;
}




public void setAmountReceived(int amountReceived) {
	this.amountReceived = amountReceived;
}




@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + Rating;
	result = prime * result + amountReceived;
	result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
	result = prime * result + ((endTime == null) ? 0 : endTime.hashCode());
	result = prime * result + id;
	result = prime * result + mentorId;
	result = prime * result + ((progress == null) ? 0 : progress.hashCode());
	result = prime * result + skillId;
	result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
	result = prime * result + ((startTime == null) ? 0 : startTime.hashCode());
	result = prime * result + ((status == null) ? 0 : status.hashCode());
	result = prime * result + userID;
	return result;
}




@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	TrainingTable other = (TrainingTable) obj;
	if (Rating != other.Rating)
		return false;
	if (amountReceived != other.amountReceived)
		return false;
	if (endDate == null) {
		if (other.endDate != null)
			return false;
	} else if (!endDate.equals(other.endDate))
		return false;
	if (endTime == null) {
		if (other.endTime != null)
			return false;
	} else if (!endTime.equals(other.endTime))
		return false;
	if (id != other.id)
		return false;
	if (mentorId != other.mentorId)
		return false;
	if (progress == null) {
		if (other.progress != null)
			return false;
	} else if (!progress.equals(other.progress))
		return false;
	if (skillId != other.skillId)
		return false;
	if (startDate == null) {
		if (other.startDate != null)
			return false;
	} else if (!startDate.equals(other.startDate))
		return false;
	if (startTime == null) {
		if (other.startTime != null)
			return false;
	} else if (!startTime.equals(other.startTime))
		return false;
	if (status == null) {
		if (other.status != null)
			return false;
	} else if (!status.equals(other.status))
		return false;
	if (userID != other.userID)
		return false;
	return true;
}




@Override
public String toString() {
	return "TrainingTable [id=" + id + ", userID=" + userID + ", mentorId=" + mentorId + ", skillId=" + skillId
			+ ", status=" + status + ", progress=" + progress + ", startTime=" + startTime + ", endTime=" + endTime
			+ ", startDate=" + startDate + ", endDate=" + endDate + ", Rating=" + Rating + ", amountReceived="
			+ amountReceived + "]";
}




		
}
