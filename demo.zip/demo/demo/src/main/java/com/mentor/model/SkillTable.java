package com.mentor.model;


import java.util.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SkillTable")
public class SkillTable {
       @Id
       @GeneratedValue(strategy = GenerationType.AUTO)
       private int id;
       @Column(name = "name")
       private int name;
       @Column(name = "toc")
       private String toc;
       @Column(name = "Duration")
       private int duration;
       @Column(name = "prerequites")
       private int prerequites;
       
   
       
        public SkillTable()
        {
        	super();
        }



		public int getId() {
			return id;
		}



		public void setId(int id) {
			this.id = id;
		}



		public int getName() {
			return name;
		}



		public void setName(int name) {
			this.name = name;
		}



		public String getToc() {
			return toc;
		}



		public void setToc(String toc) {
			this.toc = toc;
		}



		public int getDuration() {
			return duration;
		}



		public void setDuration(int duration) {
			this.duration = duration;
		}



		public int getPrerequites() {
			return prerequites;
		}



		public void setPrerequites(int prerequites) {
			this.prerequites = prerequites;
		}



		

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + duration;
			result = prime * result + id;
			result = prime * result + name;
			result = prime * result + prerequites;
			result = prime * result + ((toc == null) ? 0 : toc.hashCode());
			return result;
		}



		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			SkillTable other = (SkillTable) obj;
			if (duration != other.duration)
				return false;
			if (id != other.id)
				return false;
			if (name != other.name)
				return false;
			if (prerequites != other.prerequites)
				return false;
			if (toc == null) {
				if (other.toc != null)
					return false;
			} else if (!toc.equals(other.toc))
				return false;
			return true;
		}



		@Override
		public String toString() {
			return "SkillTable [id=" + id + ", name=" + name + ", toc=" + toc + ", duration=" + duration
					+ ", prerequites=" + prerequites + "]";
		}
        
}

