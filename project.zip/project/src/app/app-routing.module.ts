import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { HomeComponent } from './home/home.component';
import { HomedashComponent } from './homedash/homedash.component';
import { MentorsignupComponent } from './mentorsignup/mentorsignup.component';
import { AdminsignupComponent } from './adminsignup/adminsignup.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { MentorprofileComponent } from './mentorprofile/mentorprofile.component';
import { AdminprofileComponent } from './adminprofile/adminprofile.component';

const routes: Routes = [{path:'',component:HomeComponent},
{path:'login',component:LoginComponent},
{path:'usersignup',component:UsersignupComponent},
{path:'mentorsignup',component:MentorsignupComponent},
{path:'adminsignup',component:AdminsignupComponent},
{path:'homedash',component:HomedashComponent},
{path:'userprofile',component:UserprofileComponent},
{path:'mentorprofile',component:MentorprofileComponent},
{path:'adminprofile',component:AdminprofileComponent},
{path:'home',component:HomeComponent},


];
 

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
