package com.mentor.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MentorSkillTable")
public class MentorSkillTable {
       @Id
       @GeneratedValue(strategy = GenerationType.AUTO)
       private int id;
       @Column(name = "mid")
       private int mid;
       @Column(name = "sid")
       private int sid;
       @Column(name = "years_of_experience")
       private int yearsOfExperience;
       @Column(name = "trainings_delivered")
       private int trainingsDelivered;
       @Column(name = "trainings_offered")
       private int trainingsOffered;

       public MentorSkillTable() {
           super();
    }

        
       public MentorSkillTable(int id, int mid, int sid, int yearsOfExperience, int trainingsDelivered,
   			int trainingsOffered) {
   		super();
   		this.id = id;
   		this.mid = mid;
   		this.sid = sid;
   		this.yearsOfExperience = yearsOfExperience;
   		this.trainingsDelivered = trainingsDelivered;
   		this.trainingsOffered = trainingsOffered;
   	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public int getTrainingsDelivered() {
		return trainingsDelivered;
	}

	public void setTrainingsDelivered(int trainingsDelivered) {
		this.trainingsDelivered = trainingsDelivered;
	}

	public int getTrainingsOffered() {
		return trainingsOffered;
	}

	public void setTrainingsOffered(int trainingsOffered) {
		this.trainingsOffered = trainingsOffered;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + mid;
		result = prime * result + sid;
		result = prime * result + trainingsDelivered;
		result = prime * result + trainingsOffered;
		result = prime * result + yearsOfExperience;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MentorSkillTable other = (MentorSkillTable) obj;
		if (id != other.id)
			return false;
		if (mid != other.mid)
			return false;
		if (sid != other.sid)
			return false;
		if (trainingsDelivered != other.trainingsDelivered)
			return false;
		if (trainingsOffered != other.trainingsOffered)
			return false;
		if (yearsOfExperience != other.yearsOfExperience)
			return false;
		return true;
	}

	

	@Override
	public String toString() {
		return "MentorSkillTable [id=" + id + ", mid=" + mid + ", sid=" + sid + ", yearsOfExperience="
				+ yearsOfExperience + ", trainingsDelivered=" + trainingsDelivered + ", trainingsOffered="
				+ trainingsOffered + "]";
	}



	

       

       

	

}
