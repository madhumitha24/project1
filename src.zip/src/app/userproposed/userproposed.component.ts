import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userproposed',
  templateUrl: './userproposed.component.html',
  styleUrls: ['./userproposed.component.css']
})
export class UserproposedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
