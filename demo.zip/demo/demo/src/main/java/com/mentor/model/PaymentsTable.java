package com.mentor.model;



import java.sql.Time;
import java.util.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PaymentsTable")
public class PaymentsTable {
       @Id
       @GeneratedValue(strategy = GenerationType.AUTO)
       private int id;
       @Column(name = "training_id")
       private int trainingId;
       @Column(name = "mentor_id`")
       private int mentorId;
       @Column(name = "txn_type")
       private String txnType;
       @Column(name = "amount")
       private int amount;
       @Column(name = "dateTime")
       private Date dateTime;
       @Column(name = "remarks")
       private String remarks;
      
       
       
       
  public PaymentsTable()
        {
        	super();
        }




public PaymentsTable(int id, int trainingId, int mentorId, String txnType, int amount, Date dateTime, String remarks) {
	super();
	this.id = id;
	this.trainingId = trainingId;
	this.mentorId = mentorId;
	this.txnType = txnType;
	this.amount = amount;
	this.dateTime = dateTime;
	this.remarks = remarks;
}




public int getId() {
	return id;
}




public void setId(int id) {
	this.id = id;
}




public int getTrainingId() {
	return trainingId;
}




public void setTrainingId(int trainingId) {
	this.trainingId = trainingId;
}




public int getMentorId() {
	return mentorId;
}




public void setMentorId(int mentorId) {
	this.mentorId = mentorId;
}




public String getTxnType() {
	return txnType;
}




public void setTxnType(String txnType) {
	this.txnType = txnType;
}




public int getAmount() {
	return amount;
}




public void setAmount(int amount) {
	this.amount = amount;
}




public Date getDateTime() {
	return dateTime;
}




public void setDateTime(Date dateTime) {
	this.dateTime = dateTime;
}




public String getRemarks() {
	return remarks;
}




public void setRemarks(String remarks) {
	this.remarks = remarks;
}




@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + amount;
	result = prime * result + ((dateTime == null) ? 0 : dateTime.hashCode());
	result = prime * result + id;
	result = prime * result + mentorId;
	result = prime * result + ((remarks == null) ? 0 : remarks.hashCode());
	result = prime * result + trainingId;
	result = prime * result + ((txnType == null) ? 0 : txnType.hashCode());
	return result;
}




@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	PaymentsTable other = (PaymentsTable) obj;
	if (amount != other.amount)
		return false;
	if (dateTime == null) {
		if (other.dateTime != null)
			return false;
	} else if (!dateTime.equals(other.dateTime))
		return false;
	if (id != other.id)
		return false;
	if (mentorId != other.mentorId)
		return false;
	if (remarks == null) {
		if (other.remarks != null)
			return false;
	} else if (!remarks.equals(other.remarks))
		return false;
	if (trainingId != other.trainingId)
		return false;
	if (txnType == null) {
		if (other.txnType != null)
			return false;
	} else if (!txnType.equals(other.txnType))
		return false;
	return true;
}




@Override
public String toString() {
	return "PaymentsTable [id=" + id + ", trainingId=" + trainingId + ", mentorId=" + mentorId + ", txnType=" + txnType
			+ ", amount=" + amount + ", dateTime=" + dateTime + ", remarks=" + remarks + "]";
}








		
}
